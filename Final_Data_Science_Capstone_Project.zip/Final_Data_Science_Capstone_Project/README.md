# Final Data Science Capstone Project: Customer Churn Prediction

## Project overview
An end-to-end machine-learning demonstration that predicts whether a sample
customer may churn. The dataset is synthetic and generated for this capstone;
it is not real customer or company data.

## Included
- `capstone.py`: data preprocessing, model training, evaluation and charts
- `requirements.txt`: Python dependencies
- `outputs/customer_churn_sample.csv`: synthetic dataset
- `outputs/`: generated metrics, test predictions and visualizations
- `Final_Data_Science_Capstone_Report.docx`: report provided separately

## Run
```bash
python -m pip install -r requirements.txt
python capstone.py
```

## Workflow
1. Inspect the dataset and missing values.
2. Separate input features and churn target.
3. Impute missing numeric/categorical values.
4. Scale numeric values and one-hot encode categorical values.
5. Split data into train and test sets.
6. Train Logistic Regression in a Scikit-learn pipeline.
7. Evaluate using accuracy, precision, recall and F1-score.
8. Export predictions, metrics and charts.

The results are for educational demonstration only. They should not be used
for decisions about real customers.
