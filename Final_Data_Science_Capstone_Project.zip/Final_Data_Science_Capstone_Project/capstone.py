from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report

OUT = Path("outputs")
OUT.mkdir(exist_ok=True)
df = pd.read_csv(OUT / "customer_churn_sample.csv")

print("Dataset shape:", df.shape)
print("\\nMissing values:\\n", df.isna().sum())
print("\\nChurn distribution:\\n", df["churn"].value_counts())

X = df.drop(columns=["customer_id", "churn"])
y = df["churn"]
numeric_features = ["tenure_months", "monthly_charges", "support_calls"]
categorical_features = ["contract_type", "internet_service", "payment_method"]

numeric_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="median")),
    ("scaler", StandardScaler())
])
categorical_pipeline = Pipeline([
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("encoder", OneHotEncoder(handle_unknown="ignore"))
])
preprocessor = ColumnTransformer([
    ("numeric", numeric_pipeline, numeric_features),
    ("categorical", categorical_pipeline, categorical_features)
])
model = Pipeline([
    ("preprocessing", preprocessor),
    ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced"))
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
model.fit(X_train, y_train)
pred = model.predict(X_test)

metrics = {
    "accuracy": accuracy_score(y_test, pred),
    "precision": precision_score(y_test, pred, zero_division=0),
    "recall": recall_score(y_test, pred, zero_division=0),
    "f1_score": f1_score(y_test, pred, zero_division=0)
}
pd.DataFrame([metrics]).to_csv(OUT / "model_metrics.csv", index=False)
print("\\nEvaluation metrics:\\n", pd.Series(metrics).round(3))
print("\\nClassification report:\\n", classification_report(y_test, pred, zero_division=0))

cm = confusion_matrix(y_test, pred)
plt.figure()
plt.imshow(cm)
plt.title("Customer Churn - Confusion Matrix")
plt.xlabel("Predicted label")
plt.ylabel("Actual label")
plt.xticks([0, 1], ["Stay", "Churn"])
plt.yticks([0, 1], ["Stay", "Churn"])
for (i, j), value in np.ndenumerate(cm):
    plt.text(j, i, str(value), ha="center", va="center")
plt.tight_layout()
plt.savefig(OUT / "confusion_matrix.png", dpi=150)
plt.close()

# Feature overview chart: average churn rate by contract type.
contract_churn = df.groupby("contract_type", dropna=False)["churn"].mean()
plt.figure()
plt.bar(contract_churn.index.astype(str), contract_churn.values)
plt.title("Churn Rate by Contract Type")
plt.xlabel("Contract type")
plt.ylabel("Churn rate")
plt.xticks(rotation=15)
plt.tight_layout()
plt.savefig(OUT / "churn_by_contract.png", dpi=150)
plt.close()

results = X_test.copy()
results["actual_churn"] = y_test.to_numpy()
results["predicted_churn"] = pred
results.to_csv(OUT / "test_predictions.csv", index=False)
print("\\nFiles saved in outputs/.")
