from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

DATA = Path("outputs/retail_analytics_data.csv")
OUT = Path("outputs")
df = pd.read_csv(DATA, parse_dates=["month"])

monthly = df.groupby("month", as_index=False)[["revenue", "orders", "marketing_spend"]].sum()
regional = df.groupby("region", as_index=False)[["revenue", "orders", "customers"]].sum()

print("Executive KPIs")
print("Total revenue:", round(df["revenue"].sum(), 2))
print("Total orders:", int(df["orders"].sum()))
print("Total customers:", int(df["customers"].sum()))
print("Average order value:", round(df["revenue"].sum() / df["orders"].sum(), 2))
print("\nRegional summary")
print(regional.to_string(index=False))
print("\nMonthly summary")
print(monthly.to_string(index=False))

plt.figure()
plt.plot(monthly["month"], monthly["revenue"], marker="o")
plt.title("Monthly Revenue Trend")
plt.xlabel("Month")
plt.ylabel("Revenue")
plt.xticks(rotation=35)
plt.tight_layout()
plt.savefig(OUT / "monthly_revenue_trend_recreated.png", dpi=150)
plt.close()

plt.figure()
plt.bar(regional["region"], regional["revenue"])
plt.title("Revenue by Region")
plt.xlabel("Region")
plt.ylabel("Total Revenue")
plt.tight_layout()
plt.savefig(OUT / "regional_revenue_recreated.png", dpi=150)
plt.close()

plt.figure()
plt.scatter(df["marketing_spend"], df["revenue"])
plt.title("Marketing Spend vs Revenue")
plt.xlabel("Marketing Spend")
plt.ylabel("Revenue")
plt.tight_layout()
plt.savefig(OUT / "marketing_vs_revenue_recreated.png", dpi=150)
plt.close()
print("\nReport analysis completed. See outputs/ for results.")
