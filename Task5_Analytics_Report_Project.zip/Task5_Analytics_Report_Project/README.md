# Task 5: Analytics Report & Insights Documentation

## Project
Retail Sales Performance Analysis using a synthetic demonstration dataset.

## Contents
- `analytics_report.py`: reproducible analysis and chart-generation script
- `outputs/retail_analytics_data.csv`: sample dataset
- `outputs/`: charts and correlation matrix
- `Task5_Analytics_Report_Insights.docx`: written analytics report (provided separately)

## Run
Install Python and Pandas/Matplotlib:
```bash
python -m pip install pandas matplotlib
python analytics_report.py
```

The dataset is synthetic and is only intended to demonstrate KPI reporting,
regional and monthly comparisons, visualization and business recommendations.
It must not be represented as real company data.
