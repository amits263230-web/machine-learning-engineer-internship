"""
Data Science Tool Mastery Project
Install: python -m pip install -r requirements.txt
Run:     python tool_mastery.py

The script generates a synthetic marketing dataset, explores it, creates charts,
and trains/evaluates a basic regression model. Outputs are saved in outputs/.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

out = Path("outputs")
out.mkdir(exist_ok=True)

# NumPy: reproducible sample data (synthetic, not real customer records).
rng = np.random.default_rng(42)
n = 240
ad_spend = rng.uniform(100, 1500, n)
visits = rng.integers(500, 10000, n)
discount = rng.uniform(0, 0.30, n)
noise = rng.normal(0, 180, n)
sales = 250 + 2.8 * ad_spend + 0.12 * visits - 900 * discount + noise

# Pandas: create, inspect, clean and summarize a DataFrame.
df = pd.DataFrame({
    "advertising_spend": ad_spend,
    "website_visits": visits,
    "discount_rate": discount,
    "sales": sales
})
print("\nPreview:\n", df.head())
print("\nData types:\n", df.dtypes)
print("\nMissing values:\n", df.isna().sum())
print("\nDescriptive statistics:\n", df.describe().round(2))
print("\nCorrelation matrix:\n", df.corr(numeric_only=True).round(2))
df = df.drop_duplicates().dropna()
df.to_csv(out / "marketing_sales_data.csv", index=False)

# Matplotlib: create and save exploratory charts.
plt.figure()
plt.hist(df["sales"], bins=20)
plt.xlabel("Sales")
plt.ylabel("Frequency")
plt.title("Distribution of Sales")
plt.tight_layout()
plt.savefig(out / "sales_distribution.png", dpi=150)
plt.close()

plt.figure()
plt.scatter(df["advertising_spend"], df["sales"])
plt.xlabel("Advertising spend")
plt.ylabel("Sales")
plt.title("Advertising Spend vs Sales")
plt.tight_layout()
plt.savefig(out / "advertising_vs_sales.png", dpi=150)
plt.close()

plt.figure()
plt.imshow(df.corr(numeric_only=True), aspect="auto")
plt.xticks(range(4), df.columns, rotation=30, ha="right")
plt.yticks(range(4), df.columns)
plt.colorbar(label="Correlation")
plt.title("Feature Correlation Matrix")
plt.tight_layout()
plt.savefig(out / "correlation_matrix.png", dpi=150)
plt.close()

# scikit-learn: train/test split, linear regression and evaluation.
features = ["advertising_spend", "website_visits", "discount_rate"]
X = df[features]
y = df["sales"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42
)
model = LinearRegression()
model.fit(X_train, y_train)
predictions = model.predict(X_test)

metrics = pd.DataFrame({
    "metric": ["MAE", "RMSE", "R2"],
    "value": [
        mean_absolute_error(y_test, predictions),
        np.sqrt(mean_squared_error(y_test, predictions)),
        r2_score(y_test, predictions)
    ]
})
metrics.to_csv(out / "model_metrics.csv", index=False)
pd.DataFrame({
    "actual_sales": y_test.to_numpy(),
    "predicted_sales": predictions
}).to_csv(out / "actual_vs_predicted.csv", index=False)

plt.figure()
plt.scatter(y_test, predictions)
plt.xlabel("Actual sales")
plt.ylabel("Predicted sales")
plt.title("Actual vs Predicted Sales")
plt.tight_layout()
plt.savefig(out / "actual_vs_predicted.png", dpi=150)
plt.close()

print("\nCompleted. Check the outputs folder.")
