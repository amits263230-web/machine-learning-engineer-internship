# Data Science Tool Mastery Project

## Overview
A reproducible mini-project demonstrating NumPy, Pandas, Matplotlib and
scikit-learn in one data-science workflow.

## Dataset
The Python script creates a synthetic marketing-and-sales dataset with advertising
spend, website visits, discount rate and sales. It is sample data generated for
this exercise, not real customer or business data.

## Setup
```bash
python -m pip install -r requirements.txt
```

## Run
```bash
python tool_mastery.py
```

## Workflow
1. NumPy generates reproducible numeric sample data.
2. Pandas creates, inspects, cleans, summarizes and exports the dataset.
3. Matplotlib creates a histogram, scatter plot, correlation matrix and
   actual-versus-predicted chart.
4. scikit-learn trains a Linear Regression model using a train/test split.
5. MAE, RMSE and R-squared are calculated and saved.

Generated CSV and PNG files are stored in the `outputs/` directory.
