"""
Hands-On Data Lab Implementation
Run: python data_lab.py
Outputs: cleaned_sales_data.csv, sales_by_category.png, monthly_sales.png
"""
import pandas as pd
import matplotlib.pyplot as plt

# Small sample dataset for demonstrating a complete data-analysis workflow.
data = {
    "Order_ID": [101, 102, 103, 104, 105, 106, 107, 108, 109, 110],
    "Date": ["2026-01-03", "2026-01-05", "2026-01-09", "2026-01-12",
             "2026-02-02", "2026-02-08", "2026-02-14", "2026-03-01",
             "2026-03-11", "2026-03-18"],
    "Category": ["Electronics", "Furniture", "Electronics", "Office",
                 "Furniture", "Office", "Electronics", "Furniture",
                 "Office", "Electronics"],
    "Quantity": [2, 1, 3, 5, 2, 4, 1, 2, 3, 2],
    "Unit_Price": [500, 1200, 500, 50, 1200, 50, 500, 1200, 50, 500],
}

df = pd.DataFrame(data)

# 1. Inspect the dataset.
print("\\n--- First five rows ---")
print(df.head())
print("\\n--- Dataset information ---")
print(df.info())
print("\\n--- Descriptive statistics ---")
print(df.describe(numeric_only=True))

# 2. Clean and transform data.
df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
df["Category"] = df["Category"].astype("string").str.strip().str.title()
df["Revenue"] = df["Quantity"] * df["Unit_Price"]
df = df.drop_duplicates()
df = df.dropna(subset=["Date", "Category", "Quantity", "Unit_Price"])

# 3. Perform basic analysis.
print("\\n--- Total revenue ---")
print(df["Revenue"].sum())
print("\\n--- Revenue by category ---")
category_sales = df.groupby("Category", as_index=False)["Revenue"].sum()
print(category_sales)
print("\\n--- Monthly revenue ---")
df["Month"] = df["Date"].dt.to_period("M").astype(str)
monthly_sales = df.groupby("Month", as_index=False)["Revenue"].sum()
print(monthly_sales)

# 4. Save cleaned data and visualizations.
df.to_csv("cleaned_sales_data.csv", index=False)

category_sales.plot(
    kind="bar", x="Category", y="Revenue", legend=False,
    title="Revenue by Product Category", ylabel="Revenue"
)
plt.tight_layout()
plt.savefig("sales_by_category.png")
plt.close()

monthly_sales.plot(
    kind="line", x="Month", y="Revenue", marker="o", legend=False,
    title="Monthly Revenue Trend", ylabel="Revenue"
)
plt.tight_layout()
plt.savefig("monthly_sales.png")
plt.close()

print("\\nAnalysis complete. CSV and chart files have been generated.")
