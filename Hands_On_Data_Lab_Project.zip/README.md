# Hands-On Data Lab Implementation

## Objective
Demonstrate a basic Python data-analysis environment and practical work in data
manipulation, visualization, and introductory analysis.

## Requirements
- Python 3.9 or later
- pandas
- matplotlib

## Setup
```bash
python -m pip install -r requirements.txt
```

## Run
```bash
python data_lab.py
```

The script creates:
- `cleaned_sales_data.csv` — cleaned dataset with calculated revenue
- `sales_by_category.png` — bar chart of revenue by category
- `monthly_sales.png` — line chart of monthly revenue

The script also prints dataset inspection, descriptive statistics, total revenue,
category-wise revenue, and monthly revenue in the terminal.
