"""
Real-World Dataset Analysis Project: Iris dataset
Install dependencies: pip install -r requirements.txt
Run: python analyze_iris.py

The CSV is included in this repository, so no internet connection is needed.
Outputs: species_summary.csv, petal_relationship.png, average_sepal_length.png
"""
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("iris_dataset.csv")

print("\\n--- Dataset preview ---")
print(df.head())
print("\\n--- Dataset information ---")
print(df.info())
print("\\n--- Descriptive statistics ---")
print(df.describe())

print("\\n--- Missing values by column ---")
print(df.isna().sum())
print("\\n--- Duplicate rows ---")
print(df.duplicated().sum())

# Data cleaning: remove duplicate records and rows missing essential measurements.
df = df.drop_duplicates()
measurement_columns = [
    "sepal length (cm)", "sepal width (cm)",
    "petal length (cm)", "petal width (cm)"
]
df = df.dropna(subset=measurement_columns + ["species"])

# Grouped analysis
summary = df.groupby("species").agg(
    sample_count=("sepal length (cm)", "count"),
    avg_sepal_length=("sepal length (cm)", "mean"),
    avg_sepal_width=("sepal width (cm)", "mean"),
    avg_petal_length=("petal length (cm)", "mean"),
    avg_petal_width=("petal width (cm)", "mean"),
).reset_index()
summary.to_csv("species_summary.csv", index=False)
print("\\n--- Summary by species ---")
print(summary.round(2))

# Visualization 1: petal measurements
plt.figure()
for species, group in df.groupby("species"):
    plt.scatter(group["petal length (cm)"], group["petal width (cm)"], label=species)
plt.xlabel("Petal length (cm)")
plt.ylabel("Petal width (cm)")
plt.title("Iris: Petal Length vs Petal Width")
plt.legend()
plt.tight_layout()
plt.savefig("petal_relationship.png", dpi=160)
plt.close()

# Visualization 2: average sepal length
plt.figure()
df.groupby("species")["sepal length (cm)"].mean().plot(kind="bar")
plt.xlabel("Species")
plt.ylabel("Mean sepal length (cm)")
plt.title("Average Sepal Length by Iris Species")
plt.tight_layout()
plt.savefig("average_sepal_length.png", dpi=160)
plt.close()

print("\\nAnalysis completed. Check the generated CSV and PNG files.")
